#Biography of Van Gogh

# signatures = system.file ("CurlSSL", cainfo = "cacert.pem", package = "RCurl")
#
# url = getURL ("https://en.wikipedia.org/wiki/Vincent_van_Gogh", cainfo = signatures,
# encoding = "UTF-8")
# gogh_parsed <- htmlParse (url, encoding = "UTF-8")

url <- "https://en.wikipedia.org/wiki/Vincent_van_Gogh"

gogh_parsed <- htmlParse (rawToChar (GET (url) $ content))

# Loading hyperlinks, print the first 5
x <- getHTMLLinks (gogh_parsed) [1: 5]
x
# Loading lists (tags <ul>, <ol>), print the first 5 lines from the 10th list
readHTMLList (gogh_parsed) [[10]] [1: 5] 