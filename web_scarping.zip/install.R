# example 1
# package for regular expressions
install.packages ("stringr")
# package for loading maps
install.packages ("maps")
# main package for web scraping
install.packages ("RCurl")
# package for working with XML, HTML, Xpath
install.packages ("XML") 

install.packages("rvest",
                 "selectr",
                 "xml2",
                 "jsonlite",
                 "tidyverse")
