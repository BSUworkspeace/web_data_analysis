# Voz'mem dannyye za 2016 god: url <- "http://www.elections.state.md.us/elections/2016/election_data/index.html" # Izvlechem vse giperssylki: links <- try(getHTMLLinks(htmlParse(rawToChar(GET(url)$content)))) #links <- getHTMLLinks(url) # Vyberem giperssylki, kotoryye zakanchivayutsya na _General.csv: filenames <- links[str_detect(links, "_General.csv")] filenames_list <- as.list(filenames) filenames_list[1:3] # Funktsiya dlya zagruzki dokumenta po giperssylke: downloadCSV <- function(filename, baseurl, folder) { dir.create(folder, showWarnings = FALSE) fileurl <- str_c(baseurl, filename) if (!file.exists(str_c(folder, "/", filename))) { download.file(fileurl, destfile = str_c(folder, "/", filename)) Sys.sleep(1) } } # Perebirayem spisok giperssylok i zagruzhayem dokumenty: for ( i in 1:length(filenames_list)) { downloadCSV(filenames_list[[i]], baseurl = "http://www.elections.state.md.us/elections/2016/election_data/", folder = "elec16_maryland") }
Ещё
1023 / 5000
Результаты перевода
# Let's take the data for 2016:
url <- "http://www.elections.state.md.us/elections/2016/election_data/index.html"
# Extract all hyperlinks:
links <- try (getHTMLLinks (htmlParse (rawToChar (GET (url) $ content))))
#links <- getHTMLLinks (url)

# Select hyperlinks that end with _General.csv:
filenames <- links [str_detect (links, "_General.csv")]
filenames_list <- as.list (filenames)
filenames_list [1: 3]

# Function for loading a document by hyperlink:
downloadCSV <- function (filename, baseurl, folder) {
  dir.create (folder, showWarnings = FALSE)
  fileurl <- str_c (baseurl, filename)
  if (! file.exists (str_c (folder, "/", filename))) {
    download.file (fileurl,
                   destfile = str_c (folder, "/", filename))
    Sys.sleep (1)
  }
}

# Loop through the list of hyperlinks and load the documents:
for (i in 1: length (filenames_list))
{
  downloadCSV (filenames_list [[i]],
               baseurl = "http://www.elections.state.md.us/elections/2016/election_data/",
               folder = "elec16_maryland")
  
} 